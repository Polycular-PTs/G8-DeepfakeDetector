using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Randomizer : MonoBehaviour
{
    private static List<string> levelPool;

    private List<string> realLevels = new List<string> { "Post1", "Post4", "Post6", "Post7", "Post10", "Post14", "Post15", "Post16", "Post18" };
    private List<string> fakeLevels = new List<string> { "Post2", "Post3", "Post5", "Post8", "Post9", "Post11", "Post12", "Post13", "Post17" };

    void Awake()
    {
        if (levelPool == null)
        {
            RefillAndShuffle();
        }
    }

    public void ClickedReal()
    {
        CheckAnswer(true);
    }

    public void ClickedFake()
    {
        CheckAnswer(false);
    }

    private void CheckAnswer(bool playerChoseReal)
    {
        string currentScene = SceneManager.GetActiveScene().name;
        int currentScore = PlayerPrefs.GetInt("Score", 0);
        bool isCorrect = false;

        if (playerChoseReal)
        {
            if (realLevels.Contains(currentScene)) isCorrect = true;
        }
        else
        {
            if (fakeLevels.Contains(currentScene)) isCorrect = true;
        }

        if (isCorrect)
        {
            currentScore++;
            PlayerPrefs.SetInt("Score", currentScore);
        }

        string explanationScene = currentScene.Replace("Post", "answer");
        SceneManager.LoadScene(explanationScene);
    }

    public void LoadNextRandomLevel()
    {
        if (levelPool != null && levelPool.Count > 0)
        {
            string nextScene = levelPool[0];
            levelPool.RemoveAt(0);
            SceneManager.LoadScene(nextScene);
        }
        else
        {
            SceneManager.LoadScene("Result");
        }
    }

    public void RestartGame()
    {
        PlayerPrefs.SetInt("Score", 0);
        RefillAndShuffle();
        LoadNextRandomLevel();
    }

    // ACHTUNG: Hier steht die Funktion, die bei dir rot sein könnte
    private void RefillAndShuffle()
    {
        levelPool = new List<string>();
        levelPool.AddRange(realLevels);
        levelPool.AddRange(fakeLevels);

        for (int i = 0; i < levelPool.Count; i++)
        {
            string temp = levelPool[i];
            int randomIndex = Random.Range(i, levelPool.Count);
            levelPool[i] = levelPool[randomIndex];
            levelPool[randomIndex] = temp;
        }
    }
}