using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnableButtonOnClick : MonoBehaviour
{
    public Button targetButton;

    void Start()
    {
        targetButton.interactable = false;
    }
}