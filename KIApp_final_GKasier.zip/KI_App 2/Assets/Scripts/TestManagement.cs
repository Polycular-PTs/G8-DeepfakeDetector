using UnityEngine;

public class ButtonTest : MonoBehaviour
{
    public void SayHello()
    {
        Debug.Log("Hallo");
    }
}
