using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PersistentProgress : MonoBehaviour
{
    public Image fillImage;
    private static PersistentProgress instance;

    void Awake()
    {

        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }


    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        int totalLevels = 18;

        int currentSceneIndex = scene.buildIndex;

        int currentLevel = currentSceneIndex;

        float progress = (float)currentLevel / (float)totalLevels;

        fillImage.fillAmount = progress;
    }
}